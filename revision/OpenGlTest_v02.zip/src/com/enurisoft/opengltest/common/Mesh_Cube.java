package com.enurisoft.opengltest.common;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.opengl.GLES20;
import android.opengl.Matrix;

import com.enurisoft.opengltest.sub.SubRenderer;

public class Mesh_Cube extends Mesh_Base
{
	private FloatBuffer mPositionBuffer;
	private FloatBuffer mNormalBuffer;
	private FloatBuffer mTexCoordBuffer;
	
	private int mTextureDataHandle;
	
	public Mesh_Cube() {
		initData();
	}

	public Mesh_Cube(final int textureID) {
		// initData
		initData();
		// load texture
		mTextureDataHandle = TextureHelper.getInstance().loadTexture(textureID);
	}
	
	public void initData() {
		// Positions
		final float[] PositionData =
		{
			// Front face
			-1.0f, 1.0f, 1.0f,				
			-1.0f, -1.0f, 1.0f,
			1.0f, 1.0f, 1.0f, 
			-1.0f, -1.0f, 1.0f, 				
			1.0f, -1.0f, 1.0f,
			1.0f, 1.0f, 1.0f,

			// Right face
			1.0f, 1.0f, 1.0f,				
			1.0f, -1.0f, 1.0f,
			1.0f, 1.0f, -1.0f,
			1.0f, -1.0f, 1.0f,				
			1.0f, -1.0f, -1.0f,
			1.0f, 1.0f, -1.0f,

			// Back face
			1.0f, 1.0f, -1.0f,				
			1.0f, -1.0f, -1.0f,
			-1.0f, 1.0f, -1.0f,
			1.0f, -1.0f, -1.0f,				
			-1.0f, -1.0f, -1.0f,
			-1.0f, 1.0f, -1.0f,

			// Left face
			-1.0f, 1.0f, -1.0f,				
			-1.0f, -1.0f, -1.0f,
			-1.0f, 1.0f, 1.0f, 
			-1.0f, -1.0f, -1.0f,				
			-1.0f, -1.0f, 1.0f, 
			-1.0f, 1.0f, 1.0f, 

			// Top face
			-1.0f, 1.0f, -1.0f,				
			-1.0f, 1.0f, 1.0f, 
			1.0f, 1.0f, -1.0f, 
			-1.0f, 1.0f, 1.0f, 				
			1.0f, 1.0f, 1.0f, 
			1.0f, 1.0f, -1.0f,

			// Bottom face
			1.0f, -1.0f, -1.0f,				
			1.0f, -1.0f, 1.0f, 
			-1.0f, -1.0f, -1.0f,
			1.0f, -1.0f, 1.0f, 				
			-1.0f, -1.0f, 1.0f,
			-1.0f, -1.0f, -1.0f,
			};				

		// Nomals
		final float[] NormalData =
		{												
		// Front face
			0.0f, 0.0f, 1.0f,				
			0.0f, 0.0f, 1.0f,
			0.0f, 0.0f, 1.0f,
			0.0f, 0.0f, 1.0f,				
			0.0f, 0.0f, 1.0f,
			0.0f, 0.0f, 1.0f,

			// Right face 
			1.0f, 0.0f, 0.0f,				
			1.0f, 0.0f, 0.0f,
			1.0f, 0.0f, 0.0f,
			1.0f, 0.0f, 0.0f,				
			1.0f, 0.0f, 0.0f,
			1.0f, 0.0f, 0.0f,

			// Back face 
			0.0f, 0.0f, -1.0f,				
			0.0f, 0.0f, -1.0f,
			0.0f, 0.0f, -1.0f,
			0.0f, 0.0f, -1.0f,				
			0.0f, 0.0f, -1.0f,
			0.0f, 0.0f, -1.0f,

			// Left face 
			-1.0f, 0.0f, 0.0f,				
			-1.0f, 0.0f, 0.0f,
			-1.0f, 0.0f, 0.0f,
			-1.0f, 0.0f, 0.0f,				
			-1.0f, 0.0f, 0.0f,
			-1.0f, 0.0f, 0.0f,

			// Top face 
			0.0f, 1.0f, 0.0f,			
			0.0f, 1.0f, 0.0f,
			0.0f, 1.0f, 0.0f,
			0.0f, 1.0f, 0.0f,				
			0.0f, 1.0f, 0.0f,
			0.0f, 1.0f, 0.0f,

			// Bottom face 
			0.0f, -1.0f, 0.0f,			
			0.0f, -1.0f, 0.0f,
			0.0f, -1.0f, 0.0f,
			0.0f, -1.0f, 0.0f,				
			0.0f, -1.0f, 0.0f,
			0.0f, -1.0f, 0.0f
			};

		// Texture Coordinate
		final float[] TexCoordData =
		{												
		// Front face
			0.0f, 0.0f, 				
			0.0f, 1.0f,
			1.0f, 0.0f,
			0.0f, 1.0f,
			1.0f, 1.0f,
			1.0f, 0.0f,				

			// Right face 
			0.0f, 0.0f, 				
			0.0f, 1.0f,
			1.0f, 0.0f,
			0.0f, 1.0f,
			1.0f, 1.0f,
			1.0f, 0.0f,	

			// Back face 
			0.0f, 0.0f, 				
			0.0f, 1.0f,
			1.0f, 0.0f,
			0.0f, 1.0f,
			1.0f, 1.0f,
			1.0f, 0.0f,	

			// Left face 
			0.0f, 0.0f, 				
			0.0f, 1.0f,
			1.0f, 0.0f,
			0.0f, 1.0f,
			1.0f, 1.0f,
			1.0f, 0.0f,	

			// Top face 
			0.0f, 0.0f, 				
			0.0f, 1.0f,
			1.0f, 0.0f,
			0.0f, 1.0f,
			1.0f, 1.0f,
			1.0f, 0.0f,	

			// Bottom face 
			0.0f, 0.0f, 				
			0.0f, 1.0f,
			1.0f, 0.0f,
			0.0f, 1.0f,
			1.0f, 1.0f,
			1.0f, 0.0f
			};

		// Initialize the buffers.
		mPositionBuffer = ByteBuffer.allocateDirect(PositionData.length * Constants.BytesPerFloat)
        .order(ByteOrder.nativeOrder()).asFloatBuffer();							
		mPositionBuffer.put(PositionData).position(0);				

		mNormalBuffer = ByteBuffer.allocateDirect(NormalData.length * Constants.BytesPerFloat)
        .order(ByteOrder.nativeOrder()).asFloatBuffer();							
		mNormalBuffer.put(NormalData).position(0);

		mTexCoordBuffer = ByteBuffer.allocateDirect(TexCoordData.length * Constants.BytesPerFloat)
		.order(ByteOrder.nativeOrder()).asFloatBuffer();
		mTexCoordBuffer.put(TexCoordData).position(0);
	}
	
	// Draw
	@Override
	public void Draw(SubRenderer.SceneInfo sceneInfo, ShaderHandle shaderHandle)
	{
        // Draw a cube.
    	// Set the active texture unit to texture unit 0.
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);

        // Bind the texture to this unit.
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mTextureDataHandle);

        // Tell the texture uniform sampler to use this texture in the shader by binding to texture unit 0.
        GLES20.glUniform1i(shaderHandle.mTextureUniformHandle, 0);

        // texture coordinate
        mTexCoordBuffer.position(0);
        GLES20.glVertexAttribPointer(shaderHandle.mTextureCoordinateHandle, Constants.TextureCoordinateDataSize, GLES20.GL_FLOAT, false, 0, mTexCoordBuffer);
		GLES20.glEnableVertexAttribArray(shaderHandle.mTextureCoordinateHandle);                       
		
		// position
		mPositionBuffer.position(0);		
        GLES20.glVertexAttribPointer(shaderHandle.mPositionHandle, Constants.PositionDataSize, GLES20.GL_FLOAT, false, 0, mPositionBuffer);
        GLES20.glEnableVertexAttribArray(shaderHandle.mPositionHandle);                       
		
		// normal
        mNormalBuffer.position(0);
        GLES20.glVertexAttribPointer(shaderHandle.mNormalHandle, Constants.NormalDataSize, GLES20.GL_FLOAT, false, 0, mNormalBuffer);
        GLES20.glEnableVertexAttribArray(shaderHandle.mNormalHandle);                
		
		// model view
        Matrix.multiplyMM(sceneInfo.mMVPMatrix, 0, sceneInfo.mViewMatrix, 0, mModelMatrix, 0);
        GLES20.glUniformMatrix4fv(shaderHandle.mMVMatrixHandle, 1, false, sceneInfo.mMVPMatrix, 0);
		
        Matrix.multiplyMM(mTemporaryMatrix, 0, sceneInfo.mProjectionMatrix, 0, sceneInfo.mMVPMatrix, 0);
        System.arraycopy(mTemporaryMatrix, 0, sceneInfo.mMVPMatrix, 0, 16);
        GLES20.glUniformMatrix4fv(shaderHandle.mMVPMatrixHandle, 1, false, sceneInfo.mMVPMatrix, 0);
		GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36);                               
	}
}
