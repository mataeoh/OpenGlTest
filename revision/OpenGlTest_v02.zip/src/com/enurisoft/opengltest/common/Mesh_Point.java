package com.enurisoft.opengltest.common;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.opengl.GLES20;
import android.opengl.Matrix;

import com.enurisoft.opengltest.sub.SubRenderer;

public class Mesh_Point extends Mesh_Base
{
}
