package com.enurisoft.opengltest.util;

public class LoggerConfig {
	public static final boolean ON = true;
}
